describe('Protractor  App Account Search', function() {
  it('Account Summary Search', function() {
	 browser.ignoreSynchronization = true
	 beforeEach(function (done) {
        window.jasmine.DEFAULT_TIMEOUT_INTERVAL = 10000;
        setTimeout(function () {
            console.log('inside timeout');
            done();
        }, 5000);
    });
	
    browser.get('https://secure.budgettracker.com/login_secure.php');
    element(by.name('username')).sendKeys('marianntsh@gmail.com');
    element(by.name('password')).sendKeys('rosh@2210');
    element(by.className('button')).click();
	browser.sleep(5000);
	element(by.xpath('//*[@id="apps_titlebar1Id"]/table/tbody/tr/td[2]/a')).click();
    browser.sleep(5000);
		expect(element(by.xpath('//*[@id="acctsumToolbarID"]/table[3]/tbody/tr[1]/td/span')).getText()).toEqual('$561.67');
  });
});
