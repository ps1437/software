describe('Protractor  App Account Search', function() {
    it('Budget Calculator', function() {
       browser.ignoreSynchronization = true
       beforeEach(function (done) {
          window.jasmine.DEFAULT_TIMEOUT_INTERVAL = 10000;
          setTimeout(function () {
              console.log('inside timeout');
              done();
          }, 5000);
      });
      
      browser.get('https://secure.budgettracker.com/login.php?sp=nouser');
      //Click on Calculator link
      element(by.partialLinkText('Calculators')).click();
 //Paycheck Net Amount: field
      element(by.name('netincome')).sendKeys(5000);
//Other Income: field
      element(by.name('otherincome')).sendKeys(100);
      //Click on Update income button
      element(by.xpath('//*[@id="calculatorbody"]/form[1]/input[3]')).click();
      //login -end
      browser.sleep(9000);
      browser.pause();
      //Total Income- botton of page
      expect(element(by.id('totalincome')).getText()).toEqual('5100');
     });
  });
  