describe ("test budget tracker", function(){
	it ("to test login", function(){
		browser.ignoreSynchronization = true;
		beforeEach(function (done) {
          window.jasmine.DEFAULT_TIMEOUT_INTERVAL = 10000;
          setTimeout(function () {
              console.log('inside timeout');
              done();
          }, 10000);
      });
		browser.get("https://secure.budgettracker.com/login_secure.php");
		element(by.name("username")).sendKeys("marianntsh@gmail.com");
		element(by.name("password")).sendKeys("rosh@2210");
		element(by.buttonText("Login")).click();
		browser.sleep(10000);
		element(by.linkText("Marian")).click();
		var bal1= element(by.name("current_balance"));//check the current balance of Marian
		browser.sleep(10000);
		element(by.linkText("My Accounts")).click();
		browser.sleep(10000);
		element(by.linkText("Moses")).click();
		browser.sleep(5000);

		var bal2= element(by.name("current_balance"));//check the current balance of Moses
		browser.sleep(10000);
		element(by.linkText("My Transactions")).click();
		browser.sleep(10000);
		element(by.linkText("Add a Transaction")).click();
		element(by.xpath('//*[@id="showhide"]/tbody/tr[1]/td[2]/div[1]/select/option[2]')).click();
		browser.pause();
		element(by.xpath('//*[@id="showhide"]/tbody/tr[1]/td[4]/input')).sendKeys(10);//Set from account to Moses
		browser.pause();
		element(by.xpath('//*[@id="accountId"]/option[3]')).click();//Set to account to Marian
		browser.sleep(10000);
		element(by.name("tamount")).sendKeys("10");
	});
});
