describe('Protractor  FeedBack', function() {
  it('Quick FeedBack', function() {
	 browser.ignoreSynchronization = true
	
	browser.manage().timeouts().implicitlyWait(5000);
    browser.get('https://secure.budgettracker.com/login_secure.php');
    element(by.name('username')).sendKeys('marianntsh@gmail.com');
    element(by.name('password')).sendKeys('rosh@2210');
    element(by.className('button')).click();
	browser.sleep(15000);
	element(by.className('quickfeedback')).click();
browser.sleep(15000);
	element(by.xpath('//*[@id="givefeedbackid"]/form/input[1]')).sendKeys("new");
browser.sleep(15000);
console.log("----------------------");
	element(by.xpath('//*[@id="givefeedbackid"]/form/textarea')).sendKeys("new post test");
   browser.sleep(25000);

	element(by.xpath('//*[@id="qsendbutton"]')).click();
	   browser.sleep(35000);

console.log("----------------------");
	var popupAlert = browser.switchTo().alert();
	  
console.log("----------------------"+popupAlert);

console.log("----------------------"+popupAlert.getText());
    popupAlert.getText().then(function(msg){
	console.log("mess "+msg);}
	);
		
        expect("").toMatch('Thank you, your feedback has been received.');

        // Close alert
        popupAlert.dismiss();

		
  });
});
