describe('Protractor Demo App', function() {
  it('should add one and two', function() {
	browser.ignoreSynchronization = true
	 beforeEach(function (done) {
        window.jasmine.DEFAULT_TIMEOUT_INTERVAL = 10000;
        setTimeout(function () {
            console.log('inside timeout');
            done();
        }, 500);
    });
    browser.get('https://secure.budgettracker.com/login_secure.php');
    element(by.name('username')).sendKeys('marianntsh@gmail.com');
    element(by.name('password')).sendKeys('rosh@2210');
    element(by.className('button')).click();
	browser.sleep(5000);
    expect(element(by.className('whiteTxt')).getText()).
        toEqual('Logged in as:'); 
  });
});
var HtmlReporter = require('protractor-beautiful-reporter');
