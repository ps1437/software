describe('Protractor  App Account Search', function() {
    it('Account Summary Search', function() {
       browser.ignoreSynchronization = true
       beforeEach(function (done) {
          window.jasmine.DEFAULT_TIMEOUT_INTERVAL = 10000;
          setTimeout(function () {
              console.log('inside timeout');
              done();
          }, 5000);
      });
      
      browser.get('https://secure.budgettracker.com/login_secure.php');
      //login -start
      element(by.name('username')).sendKeys('marianntsh@gmail.com');
      element(by.name('password')).sendKeys('rosh@2210');
      element(by.className('button')).click();
      //login -end
      browser.sleep(5000);
      //click on first check box
      element(by.name('account_1')).click();
      //click on delete button
      browser.sleep(5000);
    
      element(by.className('redButton button')).click();

      let ale = browser.switchTo().alert();

      ale.accept();

     //Check the available balance
     browser.sleep(5000);

      browser.sleep(5000);
          expect(element(by.xpath('//*[@id="acctsumToolbarID"]/table[3]/tbody/tr[1]/td/span')).getText()).toEqual('$561.67');
    });
  });
  