describe('Protractor  Budget Calculator', function () {
    it('Budget Calculator', function () {
        browser.ignoreSynchronization = true
        beforeEach(function (done) {
            window.jasmine.DEFAULT_TIMEOUT_INTERVAL = 10000;
            setTimeout(function () {
                console.log('inside timeout');
                done();
            }, 5000);
        });

        browser.get('https://secure.budgettracker.com/login.php?sp=nouser');
        //Click on Calculator link
        element(by.partialLinkText('Calculators')).click();
        //Dropdown  - 3 option mortage calculator
        element(by.xpath('//*[@id="calculatorsId"]/option[3]')).click();
        //Mortgage Amount:
        element(by.id('mamount')).sendKeys(100);
        //Mortgage Term in Years: field
        element(by.id('myears')).sendKeys(100);
        //Interest Rate per Year:  field
        element(by.id('minterest')).sendKeys(100);

        //Click on Calculator mortage button      
        element(by.xpath('//*[@id="calculatorbody"]/form/input[4]')).click();
        //login -end

        browser.sleep(8000);
        //Total Income- botton of page
        expect(element(by.id('totalMortageId')).getText()).toEqual('Your monthly mortgage payment will be: $8.33');
    });
});
