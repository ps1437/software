describe('Protractor  App ADD ACCOUNT', function() {
    it('Add Account Details', function() {
       browser.ignoreSynchronization = true
       beforeEach(function (done) {
          window.jasmine.DEFAULT_TIMEOUT_INTERVAL = 10000;
          setTimeout(function () {
              console.log('inside timeout');
              done();
          }, 5000);
      });
      
      browser.get('https://secure.budgettracker.com/login_secure.php');
      //login -start
      element(by.name('username')).sendKeys('marianntsh@gmail.com');
      element(by.name('password')).sendKeys('rosh@2210');
      element(by.className('button')).click();
      //login -end
    browser.sleep(5000);
    //click on New Account button
    element(by.xpath('//*[@id="subnavnewentryId"]/a')).click();
    browser.sleep(5000);
    //Account name filed
    element(by.xpath('//*[@id="accountNameId"]')).sendKeys("TESTAMOUNT")
    //Current balance  filed
    element(by.xpath('//*[@id="newaccountID2"]/tbody/tr[2]/td[2]/input')).sendKeys(10);
    //Account NUmber  filed
    element(by.xpath('//*[@id="accountNumberId"]')).sendKeys(1234568);
    //Account Type  field -dropdown - 4 options
    element(by.xpath(`//*[@id="newaccountID2"]/tbody/tr[4]/td[2]/select[1]/option[4]`)).click();
    //Current balance  field -dropdown - 3 option
    element(by.xpath('//*[@id="acctcurrencyidnew"]/option[3]')).click();
    browser.sleep(5000);
    //Exchnage rate text field
    element(by.name('exchangerate')).sendKeys(20);
    //Xpath of ADD account button
    element(by.xpath('//*[@id="newaccountID2"]/tbody/tr[9]/td/input[1]')).click();
    browser.sleep(3000);
    //Total amount
    expect(element(by.xpath('//*[@id="accountupdate_div"]')).getText()).toEqual('Success! Your account has been saved.');
  });
});
  